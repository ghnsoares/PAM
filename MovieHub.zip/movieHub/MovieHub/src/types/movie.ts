export interface Movie {
  id: string;
  title: string;
  year: number | null;
  genre: string;
  director: string;
  duration: number | null;
  rating: number;
  status: 'Assistido' | 'Assistindo' | 'Quero assistir';
  favorite: boolean;
  poster: string;
  synopsis: string;
  addedDate: string;
}

export interface UserProfile {
  name: string;
  email: string;
  memberSince: string;
  avatar: string;
  stats: {
    totalMovies: number;
    favoritesCount: number;
    watchedCount: number;
  };
}
