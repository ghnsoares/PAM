import { Movie } from '../types/movie';

// Endereço da API. Em celular físico use o IP do computador (veja .env.example).
const BASE_URL = process.env.EXPO_PUBLIC_API_URL ?? 'http://localhost:3000';

export interface ApiUser {
  name: string;
  email: string;
  memberSince: string;
  avatar: string;
}

let token: string | null = null;

async function request<T>(path: string, method = 'GET', body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(BASE_URL + path, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new Error('Não foi possível conectar ao servidor.');
  }
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.error ?? 'Erro inesperado. Tente novamente.');
  return data as T;
}

async function authenticate(path: string, body: object): Promise<ApiUser> {
  const data = await request<{ token: string; user: ApiUser }>(path, 'POST', body);
  token = data.token;
  return data.user;
}

export const api = {
  login: (email: string, password: string) => authenticate('/auth/login', { email, password }),
  register: (name: string, email: string, password: string) =>
    authenticate('/auth/register', { name, email, password }),
  logout: async () => {
    try {
      await request<null>('/auth/logout', 'POST');
    } finally {
      token = null;
    }
  },
  getMovies: () => request<Movie[]>('/movies'),
  createMovie: (title: string, genre: string, rating: number) =>
    request<Movie>('/movies', 'POST', { title, genre, rating }),
  updateMovie: (id: string, title: string, genre: string, rating: number) =>
    request<Movie>(`/movies/${id}`, 'PUT', { title, genre, rating }),
  toggleFavorite: (id: string) => request<Movie>(`/movies/${id}/favorite`, 'PATCH'),
  deleteMovie: (id: string) => request<null>(`/movies/${id}`, 'DELETE'),
};
