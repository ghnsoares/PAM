import { Alert, Platform } from 'react-native';

// Alert.alert não funciona no Expo Web, então usamos window.alert nele.
export function notify(message: string) {
  if (Platform.OS === 'web') {
    window.alert(message);
  } else {
    Alert.alert('MovieHub', message);
  }
}
