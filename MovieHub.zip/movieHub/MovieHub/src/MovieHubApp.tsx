import React, { useCallback, useState } from 'react';
import { Share, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

import { Movie, UserProfile } from './types/movie';
import { colors } from './theme/colors';
import { api, ApiUser } from './services/api';
import { notify } from './services/notify';
import TabBar, { Tab } from './components/tabbar';

import SplashScreen from './screens/splash';
import LoginScreen from './screens/login';
import RegisterScreen from './screens/register';
import HomeScreen from './screens/home';
import MoviesScreen from './screens/movies';
import FavoritesScreen from './screens/favorites';
import ProfileScreen from './screens/profile';
import MovieDetailsScreen from './screens/moviedetails';
import MovieCreateScreen from './screens/moviecreate';
import MovieDeleteScreen from './screens/moviedelete';

type Auth = 'splash' | 'login' | 'register' | 'app';
type Overlay = { type: 'details' | 'edit' | 'delete'; id: string } | { type: 'create' } | null;

const errorMessage = (err: unknown) => (err instanceof Error ? err.message : 'Erro inesperado.');

export default function MovieHubApp() {
  const [auth, setAuth] = useState<Auth>('splash');
  const [tab, setTab] = useState<Tab>('home');
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [user, setUser] = useState<ApiUser | null>(null);
  const [movies, setMovies] = useState<Movie[]>([]);

  const handleSplashFinish = useCallback(() => setAuth('login'), []);

  // Depois de autenticar, busca os filmes no banco e entra no app.
  const enter = async (apiUser: ApiUser) => {
    setMovies(await api.getMovies());
    setUser(apiUser);
    setTab('home');
    setOverlay(null);
    setAuth('app');
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      await enter(await api.login(email.trim(), password));
    } catch (err) {
      notify(errorMessage(err));
    }
  };

  const handleRegister = async (name: string, email: string, password: string) => {
    try {
      await enter(await api.register(name, email.trim(), password));
    } catch (err) {
      notify(errorMessage(err));
    }
  };

  const handleLogout = async () => {
    try {
      await api.logout();
    } catch {
      // a sessão local é encerrada mesmo se o servidor não responder
    }
    setUser(null);
    setMovies([]);
    setOverlay(null);
    setAuth('login');
  };

  const replaceMovie = (updated: Movie) =>
    setMovies((list) => list.map((m) => (m.id === updated.id ? updated : m)));

  const handleToggleFavorite = async (id: string) => {
    try {
      replaceMovie(await api.toggleFavorite(id));
    } catch (err) {
      notify(errorMessage(err));
    }
  };

  const handleCreate = async (title: string, genre: string, rating: number) => {
    try {
      const created = await api.createMovie(title.trim(), genre.trim(), rating);
      setMovies((list) => [created, ...list]);
      setOverlay(null);
    } catch (err) {
      notify(errorMessage(err));
    }
  };

  const handleEdit = async (id: string, title: string, genre: string, rating: number) => {
    try {
      replaceMovie(await api.updateMovie(id, title.trim(), genre.trim(), rating));
      setOverlay({ type: 'details', id });
    } catch (err) {
      notify(errorMessage(err));
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteMovie(id);
      setMovies((list) => list.filter((m) => m.id !== id));
      setOverlay(null);
    } catch (err) {
      notify(errorMessage(err));
    }
  };

  const handleShare = async (movie: Movie) => {
    try {
      await Share.share({ message: `${movie.title} — ★ ${movie.rating}/5.0 no MovieHub` });
    } catch {
      // compartilhamento cancelado ou indisponível
    }
  };

  const selected = overlay && overlay.type !== 'create' ? movies.find((m) => m.id === overlay.id) : undefined;
  const selectMovie = (movie: Movie) => setOverlay({ type: 'details', id: movie.id });

  const profile: UserProfile | null = user && {
    ...user,
    stats: {
      totalMovies: movies.length,
      favoritesCount: movies.filter((m) => m.favorite).length,
      watchedCount: movies.filter((m) => m.status === 'Assistido').length,
    },
  };

  let content: React.ReactNode = null;
  let showTabs = false;

  if (auth === 'splash') {
    content = <SplashScreen onFinish={handleSplashFinish} />;
  } else if (auth === 'login') {
    content = <LoginScreen onLogin={handleLogin} onNavigateRegister={() => setAuth('register')} />;
  } else if (auth === 'register') {
    content = <RegisterScreen onRegister={handleRegister} onNavigateLogin={() => setAuth('login')} />;
  } else if (overlay?.type === 'create') {
    content = <MovieCreateScreen onCancel={() => setOverlay(null)} onSubmit={handleCreate} />;
  } else if (overlay && selected && overlay.type === 'details') {
    content = (
      <MovieDetailsScreen
        movie={selected}
        onBack={() => setOverlay(null)}
        onEdit={() => setOverlay({ type: 'edit', id: selected.id })}
        onDelete={() => setOverlay({ type: 'delete', id: selected.id })}
        onShare={() => handleShare(selected)}
      />
    );
  } else if (overlay && selected && overlay.type === 'edit') {
    content = (
      <MovieCreateScreen
        movie={selected}
        onCancel={() => setOverlay({ type: 'details', id: selected.id })}
        onSubmit={(title, genre, rating) => handleEdit(selected.id, title, genre, rating)}
      />
    );
  } else if (overlay && selected && overlay.type === 'delete') {
    content = (
      <MovieDeleteScreen
        movie={selected}
        onConfirm={() => handleDelete(selected.id)}
        onCancel={() => setOverlay({ type: 'details', id: selected.id })}
      />
    );
  } else {
    showTabs = true;
    if (tab === 'home') {
      content = (
        <HomeScreen
          userName={user?.name ?? ''}
          movies={movies}
          onSelectMovie={selectMovie}
          onNavigateCreate={() => setOverlay({ type: 'create' })}
        />
      );
    } else if (tab === 'movies') {
      content = <MoviesScreen movies={movies} onSelectMovie={selectMovie} onToggleFavorite={handleToggleFavorite} />;
    } else if (tab === 'favorites') {
      content = <FavoritesScreen movies={movies} onSelectMovie={selectMovie} />;
    } else if (profile) {
      content = <ProfileScreen profile={profile} onLogout={handleLogout} />;
    }
  }

  // Telas de login/cadastro/splash usam #101014; as demais usam colors.background.
  const background = auth === 'app' ? colors.background : '#101014';

  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: background }}>
        <View style={{ flex: 1 }}>{content}</View>
        {showTabs && <TabBar active={tab} onChange={setTab} />}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
