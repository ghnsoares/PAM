import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import { Movie } from '../../types/movie';
import styles from './styles';

interface Props {
  movie?: Movie;
  onCancel: () => void;
  onSubmit: (title: string, genre: string, rating: number) => void;
}

export default function MovieCreateScreen({ movie, onCancel, onSubmit }: Props) {
  const [title, setTitle] = useState(movie?.title ?? '');
  const [genre, setGenre] = useState(movie?.genre ?? '');
  const [rating, setRating] = useState(movie ? String(movie.rating) : '4.5');

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>{movie ? 'Editar Filme' : 'Novo Filme'}</Text>

      <View style={styles.field}>
        <Text style={styles.label}>Título</Text>
        <TextInput style={styles.input} value={title} onChangeText={setTitle} placeholder="Nome do filme" placeholderTextColor="#666" />
      </View>

      <View style={styles.field}>
        <Text style={styles.label}>Gênero</Text>
        <TextInput style={styles.input} value={genre} onChangeText={setGenre} placeholder="Ex: Ação, Drama" placeholderTextColor="#666" />
      </View>

      <View style={styles.field}>
        <Text style={styles.label}>Nota (0 - 5)</Text>
        <TextInput style={styles.input} value={rating} onChangeText={setRating} keyboardType="numeric" placeholderTextColor="#666" />
      </View>

      <TouchableOpacity style={styles.submitBtn} onPress={() => onSubmit(title, genre, parseFloat(rating.replace(',', '.')) || 4.0)}>
        <Text style={styles.submitText}>Salvar Filme</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.cancelBtn} onPress={onCancel}>
        <Text style={styles.cancelText}>Cancelar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}