import MovieHubApp from '@/src/MovieHubApp';

export default function Index() {
  return <MovieHubApp />;
}
