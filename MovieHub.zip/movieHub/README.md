# MovieHub + PostgreSQL

```
movieHub/
├── MovieHub/      App Expo (React Native) — telas e estilos originais
├── backend/       API Express + PostgreSQL
│   ├── db/        schema.sql, init.js (cria tabelas), seed.js (dados de exemplo)
│   └── src/       server.js, db.js, auth.js, routes/
└── simulador.html Simulador (abra no navegador)
```

O app **não** acessa o banco direto: ele fala com a API (`fetch`), e a API fala com o PostgreSQL.
É o jeito seguro — a senha do banco nunca fica dentro do app.

## 1. Banco de dados

Requisitos: PostgreSQL 13+ e Node 20.6+.

```bash
createdb moviehub                    # ou: psql -U postgres -c "CREATE DATABASE moviehub;"
cd backend
cp .env.example .env                 # ajuste usuário/senha em DATABASE_URL
npm install
npm run db:init                      # cria as tabelas (pode rodar de novo sem problema)
npm run db:seed                      # opcional: usuário demo@moviehub.com / demo123 + 6 filmes
npm start                            # API em http://localhost:3000
```

Tabelas: `users` (senha com hash scrypt), `sessions` (token de login, só o hash fica salvo)
e `movies` (cada filme pertence a um usuário).

## 2. App

```bash
cd MovieHub
cp .env.example .env                 # EXPO_PUBLIC_API_URL: veja os endereços no arquivo
npm install
npx expo start                       # w = navegador · a = Android · i = iOS
```

> Em celular físico, `localhost` é o próprio celular: use o IP do seu computador
> (ex.: `http://192.168.0.10:3000`) e mantenha os dois na mesma rede.

## API

| Método | Rota                   | Descrição                          |
|--------|------------------------|------------------------------------|
| POST   | /auth/register         | cria conta e já entra              |
| POST   | /auth/login            | entra                              |
| POST   | /auth/logout           | encerra a sessão                   |
| GET    | /auth/me               | dados do usuário                   |
| GET    | /movies                | lista os filmes do usuário         |
| POST   | /movies                | cria filme                         |
| PUT    | /movies/:id            | edita filme                        |
| PATCH  | /movies/:id/favorite   | alterna favorito                   |
| DELETE | /movies/:id            | exclui filme                       |

Segurança básica incluída: consultas parametrizadas (sem SQL injection), senhas com scrypt + salt,
tokens aleatórios guardados como hash, validação de entrada com CHECKs no banco, e todo filme
é filtrado pelo `user_id` do token (ninguém acessa dados de outro usuário).
Em produção, use HTTPS e defina `CORS_ORIGIN` para o seu domínio.
