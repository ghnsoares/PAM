// Cria as tabelas: npm run db:init
const fs = require('fs');
const path = require('path');
const pool = require('../src/db');

(async () => {
  try {
    await pool.query(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
    console.log('Tabelas criadas/verificadas com sucesso.');
  } catch (err) {
    console.error('Erro ao criar tabelas:', err.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
