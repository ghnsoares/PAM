// Dados de exemplo (opcional): npm run db:seed
// Cria o usuário demo@moviehub.com (senha: demo123) com alguns filmes.
const pool = require('../src/db');
const { hashPassword } = require('../src/auth');

const poster = (t) => `https://placehold.co/300x450/14141C/E50914/png?text=${encodeURIComponent(t)}`;

const MOVIES = [
  ['Interestelar', 2014, 'Ficção Científica', 'Christopher Nolan', 169, 4.8, 'Assistido', true,
    'Um grupo de astronautas viaja através de um buraco de minhoca em busca de um novo lar para a humanidade.'],
  ['Parasita', 2019, 'Suspense', 'Bong Joon-ho', 132, 4.7, 'Assistido', true,
    'Uma família pobre se infiltra, aos poucos, na casa de uma família rica, com consequências inesperadas.'],
  ['O Poderoso Chefão', 1972, 'Crime', 'Francis Ford Coppola', 175, 4.9, 'Assistido', false,
    'A saga de uma família mafiosa italiana em Nova York e a transição de poder entre pai e filho.'],
  ['A Origem', 2010, 'Ficção Científica', 'Christopher Nolan', 148, 4.6, 'Assistindo', true,
    'Um ladrão especializado em invadir sonhos recebe a missão de plantar uma ideia na mente de um alvo.'],
  ['Cidade de Deus', 2002, 'Drama', 'Fernando Meirelles', 130, 4.7, 'Quero assistir', false,
    'A vida de jovens em uma favela do Rio de Janeiro entre o crime e a busca por outro caminho.'],
  ['A Viagem de Chihiro', 2001, 'Animação', 'Hayao Miyazaki', 125, 4.8, 'Quero assistir', false,
    'Uma menina fica presa em um mundo de espíritos e precisa trabalhar para libertar seus pais.'],
];

(async () => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const email = 'demo@moviehub.com';
    let { rows } = await client.query('SELECT id FROM users WHERE email = $1', [email]);
    if (rows.length === 0) {
      ({ rows } = await client.query(
        'INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id',
        ['Demo', email, await hashPassword('demo123')]
      ));
    }
    const userId = rows[0].id;
    const { rows: existing } = await client.query('SELECT 1 FROM movies WHERE user_id = $1 LIMIT 1', [userId]);
    if (existing.length === 0) {
      for (const [title, year, genre, director, duration, rating, status, favorite, synopsis] of MOVIES) {
        await client.query(
          `INSERT INTO movies (user_id, title, year, genre, director, duration, rating, status, favorite, poster, synopsis)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
          [userId, title, year, genre, director, duration, rating, status, favorite, poster(title), synopsis]
        );
      }
    }
    await client.query('COMMIT');
    console.log('Seed concluído. Login: demo@moviehub.com / demo123');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Erro no seed:', err.message);
    process.exitCode = 1;
  } finally {
    client.release();
    await pool.end();
  }
})();
