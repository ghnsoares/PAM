-- MovieHub: estrutura do banco (PostgreSQL 13+)
-- Pode ser executado várias vezes sem erro.

CREATE TABLE IF NOT EXISTS users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text        NOT NULL CHECK (btrim(name) <> ''),
  email         text        NOT NULL UNIQUE CHECK (email = lower(email)),
  password_hash text        NOT NULL,
  avatar        text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- Sessões de login: guardamos apenas o hash do token.
CREATE TABLE IF NOT EXISTS sessions (
  token_hash text        PRIMARY KEY,
  user_id    uuid        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS movies (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      text         NOT NULL CHECK (btrim(title) <> ''),
  year       integer      CHECK (year BETWEEN 1888 AND 2200),
  genre      text         NOT NULL DEFAULT '',
  director   text         NOT NULL DEFAULT '',
  duration   integer      CHECK (duration > 0),
  rating     numeric(2,1) NOT NULL DEFAULT 0 CHECK (rating BETWEEN 0 AND 5),
  status     text         NOT NULL DEFAULT 'Quero assistir'
                          CHECK (status IN ('Assistido', 'Assistindo', 'Quero assistir')),
  favorite   boolean      NOT NULL DEFAULT false,
  poster     text         NOT NULL DEFAULT '',
  synopsis   text         NOT NULL DEFAULT '',
  created_at timestamptz  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS movies_user_created_idx ON movies (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions (user_id);
