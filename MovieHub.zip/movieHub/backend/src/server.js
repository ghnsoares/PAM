const express = require('express');

const app = express();
app.disable('x-powered-by');

// CORS (necessário só para o Expo Web; no celular não se aplica).
const origin = process.env.CORS_ORIGIN || 'http://localhost:8081';
app.use((req, res, next) => {
  res.set('Access-Control-Allow-Origin', origin);
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.set('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use(express.json({ limit: '10kb' }));

app.get('/health', (req, res) => res.json({ ok: true }));
app.use('/auth', require('./routes/auth'));
app.use('/movies', require('./routes/movies'));

app.use((req, res) => res.status(404).json({ error: 'Rota não encontrada.' }));

// Tratamento de erros: nunca expõe detalhes internos ao cliente.
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON inválido.' });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Requisição muito grande.' });
  console.error(err);
  res.status(500).json({ error: 'Erro interno do servidor.' });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`MovieHub API rodando em http://localhost:${port}`));
