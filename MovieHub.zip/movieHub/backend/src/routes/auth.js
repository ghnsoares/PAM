const express = require('express');
const pool = require('../db');
const { hashPassword, verifyPassword, createSession, requireAuth } = require('../auth');

const router = express.Router();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const str = (v) => (typeof v === 'string' ? v.trim() : '');

// Hash falso para gastar o mesmo tempo quando o e-mail não existe.
const DUMMY_HASH = `${'00'.repeat(16)}:${'00'.repeat(64)}`;

function avatarFor(name) {
  return `https://ui-avatars.com/api/?background=E50914&color=fff&size=180&name=${encodeURIComponent(name)}`;
}

function toUser(row) {
  return {
    name: row.name,
    email: row.email,
    memberSince: new Date(row.created_at).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }),
    avatar: row.avatar || avatarFor(row.name),
  };
}

// POST /auth/register  { name, email, password }
router.post('/register', wrap(async (req, res) => {
  const name = str(req.body?.name);
  const email = str(req.body?.email).toLowerCase();
  const password = typeof req.body?.password === 'string' ? req.body.password : '';

  if (!name || name.length > 100) return res.status(400).json({ error: 'Informe um nome válido.' });
  if (!EMAIL_RE.test(email) || email.length > 254) return res.status(400).json({ error: 'Informe um e-mail válido.' });
  if (password.length < 6 || password.length > 200) {
    return res.status(400).json({ error: 'A senha deve ter pelo menos 6 caracteres.' });
  }

  try {
    const { rows } = await pool.query(
      `INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3)
       RETURNING id, name, email, avatar, created_at`,
      [name, email, await hashPassword(password)]
    );
    res.status(201).json({ token: await createSession(rows[0].id), user: toUser(rows[0]) });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Este e-mail já está cadastrado.' });
    throw err;
  }
}));

// POST /auth/login  { email, password }
router.post('/login', wrap(async (req, res) => {
  const email = str(req.body?.email).toLowerCase();
  const password = typeof req.body?.password === 'string' ? req.body.password : '';

  const { rows } = await pool.query(
    'SELECT id, name, email, avatar, created_at, password_hash FROM users WHERE email = $1',
    [email]
  );
  const user = rows[0];
  const ok = await verifyPassword(password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok) return res.status(401).json({ error: 'E-mail ou senha inválidos.' });

  res.json({ token: await createSession(user.id), user: toUser(user) });
}));

// POST /auth/logout
router.post('/logout', requireAuth, wrap(async (req, res) => {
  await pool.query('DELETE FROM sessions WHERE token_hash = $1', [req.tokenHash]);
  res.sendStatus(204);
}));

// GET /auth/me
router.get('/me', requireAuth, wrap(async (req, res) => {
  const { rows } = await pool.query(
    'SELECT name, email, avatar, created_at FROM users WHERE id = $1',
    [req.userId]
  );
  res.json(toUser(rows[0]));
}));

module.exports = router;
