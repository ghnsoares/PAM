const express = require('express');
const pool = require('../db');
const { requireAuth } = require('../auth');

const router = express.Router();
router.use(requireAuth); // todas as rotas de filmes exigem login

const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const STATUSES = ['Assistido', 'Assistindo', 'Quero assistir'];
const NO_POSTER = 'https://placehold.co/300x450/14141C/9A9A9A/png?text=Sem+capa';

const COLUMNS = `id, title, year, genre, director, duration, rating::float8 AS rating,
                 status, favorite, poster, synopsis, created_at AS "addedDate"`;

const toMovie = (row) => ({ ...row, poster: row.poster || NO_POSTER });

// Valida o corpo e devolve só os campos permitidos (nomes de coluna fixos = sem SQL injection).
function parseMovie(body) {
  const data = {};
  const text = (key, max, required) => {
    if (body[key] === undefined) return;
    if (typeof body[key] !== 'string') throw new Error(`Campo inválido: ${key}.`);
    const value = body[key].trim();
    if ((required && !value) || value.length > max) throw new Error(`Campo inválido: ${key}.`);
    data[key] = value;
  };
  const int = (key, min, max) => {
    if (body[key] === undefined) return;
    if (!Number.isInteger(body[key]) || body[key] < min || body[key] > max) throw new Error(`Campo inválido: ${key}.`);
    data[key] = body[key];
  };

  text('title', 200, true);
  text('genre', 100);
  text('director', 100);
  text('synopsis', 2000);
  text('poster', 500);
  if (data.poster && !/^https?:\/\//i.test(data.poster)) throw new Error('Campo inválido: poster.');
  int('year', 1888, 2200);
  int('duration', 1, 1000);

  if (body.rating !== undefined) {
    if (typeof body.rating !== 'number' || !(body.rating >= 0 && body.rating <= 5)) {
      throw new Error('A nota deve estar entre 0 e 5.');
    }
    data.rating = Math.round(body.rating * 10) / 10;
  }
  if (body.status !== undefined) {
    if (!STATUSES.includes(body.status)) throw new Error('Status inválido.');
    data.status = body.status;
  }
  if (body.favorite !== undefined) {
    if (typeof body.favorite !== 'boolean') throw new Error('Campo inválido: favorite.');
    data.favorite = body.favorite;
  }
  return data;
}

// Garante que :id é um UUID antes de ir ao banco.
router.param('id', (req, res, next, id) => {
  if (!UUID_RE.test(id)) return res.status(404).json({ error: 'Filme não encontrado.' });
  next();
});

const notFound = (res) => res.status(404).json({ error: 'Filme não encontrado.' });

// GET /movies
router.get('/', wrap(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT ${COLUMNS} FROM movies WHERE user_id = $1 ORDER BY created_at DESC, id`,
    [req.userId]
  );
  res.json(rows.map(toMovie));
}));

// POST /movies  { title, genre?, rating?, ... }
router.post('/', wrap(async (req, res) => {
  let data;
  try {
    data = parseMovie(req.body || {});
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }
  if (!data.title) return res.status(400).json({ error: 'Informe o título do filme.' });

  const keys = Object.keys(data);
  const { rows } = await pool.query(
    `INSERT INTO movies (user_id, ${keys.join(', ')})
     VALUES ($1, ${keys.map((_, i) => `$${i + 2}`).join(', ')})
     RETURNING ${COLUMNS}`,
    [req.userId, ...keys.map((k) => data[k])]
  );
  res.status(201).json(toMovie(rows[0]));
}));

// PUT /movies/:id  { campos a alterar }
router.put('/:id', wrap(async (req, res) => {
  let data;
  try {
    data = parseMovie(req.body || {});
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }
  const keys = Object.keys(data);
  if (keys.length === 0) return res.status(400).json({ error: 'Nada para atualizar.' });

  const { rows } = await pool.query(
    `UPDATE movies SET ${keys.map((k, i) => `${k} = $${i + 1}`).join(', ')}
     WHERE id = $${keys.length + 1} AND user_id = $${keys.length + 2}
     RETURNING ${COLUMNS}`,
    [...keys.map((k) => data[k]), req.params.id, req.userId]
  );
  if (rows.length === 0) return notFound(res);
  res.json(toMovie(rows[0]));
}));

// PATCH /movies/:id/favorite  (alterna favorito)
router.patch('/:id/favorite', wrap(async (req, res) => {
  const { rows } = await pool.query(
    `UPDATE movies SET favorite = NOT favorite WHERE id = $1 AND user_id = $2 RETURNING ${COLUMNS}`,
    [req.params.id, req.userId]
  );
  if (rows.length === 0) return notFound(res);
  res.json(toMovie(rows[0]));
}));

// DELETE /movies/:id
router.delete('/:id', wrap(async (req, res) => {
  const { rows } = await pool.query(
    'DELETE FROM movies WHERE id = $1 AND user_id = $2 RETURNING id',
    [req.params.id, req.userId]
  );
  if (rows.length === 0) return notFound(res);
  res.sendStatus(204);
}));

module.exports = router;
