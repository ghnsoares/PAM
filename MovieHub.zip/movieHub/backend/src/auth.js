const crypto = require('crypto');
const { promisify } = require('util');
const pool = require('./db');

const scrypt = promisify(crypto.scrypt);
const SESSION_DAYS = 30;

// Senha: scrypt com salt aleatório (nativo do Node, sem dependências extras).
async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = await scrypt(password, salt, 64);
  return `${salt.toString('hex')}:${hash.toString('hex')}`;
}

async function verifyPassword(password, stored) {
  const [saltHex, hashHex] = stored.split(':');
  const hash = await scrypt(password, Buffer.from(saltHex, 'hex'), 64);
  return crypto.timingSafeEqual(hash, Buffer.from(hashHex, 'hex'));
}

const sha256 = (value) => crypto.createHash('sha256').update(value).digest('hex');

// Cria uma sessão e devolve o token (no banco fica só o hash dele).
async function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  await pool.query('DELETE FROM sessions WHERE expires_at < now()');
  await pool.query(
    `INSERT INTO sessions (token_hash, user_id, expires_at)
     VALUES ($1, $2, now() + make_interval(days => $3))`,
    [sha256(token), userId, SESSION_DAYS]
  );
  return token;
}

// Middleware: exige "Authorization: Bearer <token>" e define req.userId.
async function requireAuth(req, res, next) {
  try {
    const match = /^Bearer ([a-f0-9]{64})$/.exec(req.headers.authorization || '');
    if (!match) return res.status(401).json({ error: 'Não autenticado.' });
    const { rows } = await pool.query(
      'SELECT user_id FROM sessions WHERE token_hash = $1 AND expires_at > now()',
      [sha256(match[1])]
    );
    if (rows.length === 0) return res.status(401).json({ error: 'Sessão expirada. Faça login novamente.' });
    req.userId = rows[0].user_id;
    req.tokenHash = sha256(match[1]);
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = { hashPassword, verifyPassword, createSession, requireAuth };
