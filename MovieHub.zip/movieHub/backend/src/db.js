const { Pool } = require('pg');

// A conexão vem da variável DATABASE_URL (arquivo .env).
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Evita derrubar o servidor se uma conexão ociosa cair.
pool.on('error', (err) => console.error('Erro no pool do PostgreSQL:', err.message));

module.exports = pool;
