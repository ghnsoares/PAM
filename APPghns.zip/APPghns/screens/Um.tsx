import Constants from "expo-constants";
import React from "react";
import { StatusBar, StyleSheet, View } from "react-native";

export default function Um() {
  return (
    <View style={styles.container}>
      <StatusBar hidden />

      <View style={styles.topo} />

      <View style={styles.baixo} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
    paddingTop: Constants.statusBarHeight,
  },

  topo: {
    flex: 0.5,
    backgroundColor: "crismon",
  },

  baixo: {
    flex: 0.5,
    backgroundColor: "salmon",
  },
});
