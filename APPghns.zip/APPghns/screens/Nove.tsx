import React, { useState } from "react";
import {
    SafeAreaView,
    StyleSheet,
    Text,
    View
} from "react-native";

import { Picker } from "@react-native-picker/picker";

export default function Nove() {
  const [perfil, setPerfil] = useState("manager");

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.moldura}>
        <Picker
          selectedValue={perfil}
          onValueChange={(itemValue) => setPerfil(itemValue)}
        >
          <Picker.Item label="Administrador" value="admin" />
          <Picker.Item label="Gestor" value="manager" />
          <Picker.Item label="Usuário" value="user" />
        </Picker>

        <Text>Perfil selecionado: {perfil}</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
  },

  moldura: {
    borderWidth: 1,
    padding: 20,
    alignSelf: "center",
    width: "90%",
    maxWidth: 270,
  },
});
