import Constants from "expo-constants";
import React from "react";
import {
    Image,
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from "react-native";

export default function Home() {
  const botoes = [
    "Um",
    "Dois",
    "Três",
    "Quatro",
    "Cinco",
    "Seis",
    "Sete",
    "Oito",
    "Nove",
    "Dez",
  ];

  return (
    <SafeAreaView style={styles.containerPai}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContainer}
      >
        <View style={styles.moldura}>
          <Image
            source={require("../assets/images/Etec.jpg")}
            style={styles.logo}
            resizeMode="contain"
          />

          <Text style={styles.titulo}>HOME</Text>

          <View style={styles.gridBotoes}>
            {botoes.map((item, index) => (
              <TouchableOpacity key={index} style={styles.botao}>
                <Text style={styles.textoBotao}>{item}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  containerPai: {
    flex: 1,
    backgroundColor: "#1c1c1c",
    paddingTop: Constants.statusBarHeight,
  },
  scrollView: {
    flex: 1,
    width: "100%",
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 30,
    paddingHorizontal: 20,
  },
  moldura: {
    width: "100%",
    maxWidth: 320,
    backgroundColor: "#2a2a2a",
    borderWidth: 1,
    borderColor: "#070707",
    borderRadius: 8,
    padding: 20,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  logo: {
    width: 140,
    height: 140,
    marginBottom: 15,
  },
  titulo: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#f1f1f1",
    marginBottom: 20,
    textAlign: "center",
  },
  gridBotoes: {
    width: "100%",
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  botao: {
    width: "47%",
    backgroundColor: "#FFA500",
    paddingVertical: 12,
    borderRadius: 6,
    marginBottom: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  textoBotao: {
    color: "#000000",
    fontSize: 16,
    fontWeight: "500",
  },
});
