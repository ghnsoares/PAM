import Onze from "../../screens/Onze";

export default function HomeScreen() {
  return <Onze />;
}
